Please include a README with your submission that briefly explains your approach to the Predator drawing and hunger_force, as well as the Flocker fear_force.

## Predator Drawing

I really wanted to make the predator a shark.
It didn't work.
I'm a little disappointed.
It's a banana now.

## `hunger_force`

## `fear_force`