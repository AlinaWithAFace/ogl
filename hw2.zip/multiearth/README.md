Draw Mode 7
---

This one was hardest to get started with in that I had a bit of trouble just getting everything piped to the shaders properly at first. Most of it was based on tutorial 8's code, and it wasn't too hard to get together based on that after just getting everything into the fragment shader.


Draw Mode 8
---

After getting the previous mode running, it was just a matter of adding in the water texture specifically with the specular coloring also pulled from tutorial 8


Draw Mode 9
---

This one was a little harder in that I had issues defining cosTheta briefly and had to swap part of it out with an abs function rather than clamping it, but it eventually seemed to work well